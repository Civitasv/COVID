create function st_geomcollfromwkb(bytea) returns geometry
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT CASE
	WHEN public.geometrytype(public.ST_GeomFromWKB($1)) = 'GEOMETRYCOLLECTION'
	THEN public.ST_GeomFromWKB($1)
	ELSE NULL END

$$;

alter function st_geomcollfromwkb(bytea) owner to postgres;

