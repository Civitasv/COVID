create function st_dwithin(rast1 raster, rast2 raster, distance double precision) returns boolean
    immutable
    parallel safe
    cost 1000
    language sql
as
$$
SELECT public.st_dwithin($1, NULL::integer, $2, NULL::integer, $3)
$$;

comment on function st_dwithin(raster, raster, double precision) is 'args: rastA, rastB, distance_of_srid - Return true if rasters rastA and rastB are within the specified distance of each other.';

alter function st_dwithin(raster, raster, double precision) owner to postgres;

