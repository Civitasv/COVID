create function st_nearestvalue(rast raster, columnx integer, rowy integer, exclude_nodata_value boolean DEFAULT true) returns double precision
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT st_nearestvalue($1, 1, st_setsrid(st_makepoint(st_rastertoworldcoordx($1, $2, $3), st_rastertoworldcoordy($1, $2, $3)), st_srid($1)), $4)
$$;

comment on function st_nearestvalue(raster, integer, integer, boolean) is 'args: rast, columnx, rowy, exclude_nodata_value=true - Returns the nearest non-NODATA value of a given bands pixel specified by a columnx and rowy or a geometric point expressed in the same spatial reference coordinate system as the raster.';

alter function st_nearestvalue(raster, integer, integer, boolean) owner to postgres;

