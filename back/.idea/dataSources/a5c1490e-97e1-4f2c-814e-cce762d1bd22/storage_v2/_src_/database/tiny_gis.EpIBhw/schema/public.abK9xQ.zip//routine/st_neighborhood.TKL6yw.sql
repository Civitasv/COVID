create function st_neighborhood(rast raster, columnx integer, rowy integer, distancex integer, distancey integer, exclude_nodata_value boolean DEFAULT true) returns double precision[]
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT public._ST_neighborhood($1, 1, $2, $3, $4, $5, $6)
$$;

comment on function st_neighborhood(raster, integer, integer, integer, integer, boolean) is 'args: rast, columnX, rowY, distanceX, distanceY, exclude_nodata_value=true - Returns a 2-D double precision array of the non-NODATA values around a given bands pixel specified by either a columnX and rowY or a geometric point expressed in the same spatial reference coordinate system as the raster.';

alter function st_neighborhood(raster, integer, integer, integer, integer, boolean) owner to postgres;

