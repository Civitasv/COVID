create function st_clip(rast raster, geom geometry, nodataval double precision, crop boolean DEFAULT true) returns raster
    immutable
    parallel safe
    language sql
as
$$
SELECT public.ST_Clip($1, NULL, $2, ARRAY[$3]::double precision[], $4)
$$;

alter function st_clip(raster, geometry, double precision, boolean) owner to postgres;

