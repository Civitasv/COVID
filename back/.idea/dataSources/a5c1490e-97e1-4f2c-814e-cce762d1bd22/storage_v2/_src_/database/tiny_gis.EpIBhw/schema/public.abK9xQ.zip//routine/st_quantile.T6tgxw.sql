create function st_quantile(rastertable text, rastercolumn text, exclude_nodata_value boolean, quantile double precision DEFAULT NULL::double precision) returns double precision
    stable
    language sql
as
$$
SELECT ( public._ST_quantile($1, $2, 1, $3, 1, ARRAY[$4]::double precision[])).value
$$;

alter function st_quantile(text, text, boolean, double precision) owner to postgres;

