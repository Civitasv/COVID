create function st_findextent(text, text) returns box2d
    immutable
    strict
    parallel safe
    language plpgsql
as
$$
DECLARE
	tablename alias for $1;
	columnname alias for $2;
	myrec RECORD;

BEGIN
	FOR myrec IN EXECUTE 'SELECT public.ST_Extent("' || columnname || '") As extent FROM "' || tablename || '"' LOOP
		return myrec.extent;
	END LOOP;
END;
$$;

alter function st_findextent(text, text) owner to postgres;

